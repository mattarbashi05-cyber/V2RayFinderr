package com.example.v2rayfinder;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(12, 18, 32), panel = Color.rgb(23, 32, 51), accent = Color.rgb(88, 166, 255), text = Color.rgb(238, 243, 250), muted = Color.rgb(165, 180, 202);
    private LinearLayout root, listBox;
    private TextView status, counts;
    private Button scanButton, exportButton;
    private final List<Node> nodes = Collections.synchronizedList(new ArrayList<>());
    private final ExecutorService pool = Executors.newFixedThreadPool(10);
    private volatile boolean scanning = false;

    static class Node { String uri, proto, host; int port; String result = "آزمایش‌نشده"; long ms = -1; Node(String u) { uri=u; proto=u.substring(0,u.indexOf(":")).toUpperCase(); parse(); }
        void parse() { try {
            if (uri.startsWith("vmess://")) { String b=uri.substring(8).split("#")[0]; while (b.length()%4!=0) b+="="; JSONObject j=new JSONObject(new String(Base64.getUrlDecoder().decode(b), StandardCharsets.UTF_8)); host=j.optString("add", ""); port=j.optInt("port",0); }
            else { URI u=URI.create(uri); host=u.getHost(); port=u.getPort(); if ((port<=0 || port>65535) && host!=null) port=(uri.startsWith("trojan://")||uri.startsWith("vless://"))?443:8388; }
        } catch(Exception ignored) {} }
    }

    @Override public void onCreate(Bundle b) { super.onCreate(b); buildUI(); }
    private void buildUI() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(22),dp(18),dp(12)); root.setBackgroundColor(bg); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView title=new TextView(this); title.setText("یابنده کانفیگ V2Ray"); title.setTextColor(text); title.setTextSize(25); title.setTypeface(null,Typeface.BOLD); root.addView(title);
        TextView sub=new TextView(this); sub.setText("جمع‌آوری منابع عمومی • حذف تکراری‌ها • بررسی اولیه سرور"); sub.setTextColor(muted); sub.setTextSize(13); sub.setPadding(0,dp(6),0,dp(16)); root.addView(sub);
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(14),dp(12),dp(14),dp(12)); card.setBackground(round(panel,18)); root.addView(card,new LinearLayout.LayoutParams(-1,-2));
        status=new TextView(this); status.setText("برای شروع، روی «جستجو و تست» بزنید."); status.setTextColor(text); status.setTextSize(15); card.addView(status);
        counts=new TextView(this); counts.setText("کانفیگ‌ها: ۰"); counts.setTextColor(muted); counts.setPadding(0,dp(8),0,0); card.addView(counts);
        scanButton=button("جستجو و تست کانفیگ‌ها",accent); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(50)); bp.topMargin=dp(12); root.addView(scanButton,bp); scanButton.setOnClickListener(v->scan());
        exportButton=button("خروجی کانفیگ‌های قابل‌دسترس",Color.rgb(38, 54, 78)); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(46)); ep.topMargin=dp(8); root.addView(exportButton,ep); exportButton.setOnClickListener(v->exportAll());
        TextView hint=new TextView(this); hint.setText("برای استفاده: روی یک کانفیگ بزنید تا کپی شود؛ سپس آن را در V2RayNG وارد کنید. این برنامه خودش VPN برقرار نمی‌کند."); hint.setTextColor(muted); hint.setTextSize(12); hint.setPadding(2,dp(10),2,dp(10)); root.addView(hint);
        ScrollView scroll=new ScrollView(this); listBox=new LinearLayout(this); listBox.setOrientation(LinearLayout.VERTICAL); scroll.addView(listBox); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    private Button button(String label,int color) { Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTextSize(15); b.setBackground(round(color,14)); return b; }
    private android.graphics.drawable.GradientDrawable round(int color,int radius) { android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(int v) { return (int)(v*getResources().getDisplayMetrics().density); }

    private void scan() {
        if(scanning) return; scanning=true; scanButton.setEnabled(false); status.setText("در حال دریافت فهرست‌های عمومی…"); listBox.removeAllViews(); nodes.clear(); counts.setText("در حال دریافت کانفیگ‌ها…");
        new Thread(() -> {
            Map<String,Node> found=new LinkedHashMap<>();
            String[] sources={
                "https://raw.githubusercontent.com/morpheusadam/v2ray-config/main/subs/bundles/lite.txt",
                "https://raw.githubusercontent.com/Alirewa/V2ray-Configs/main/config.txt"
            };
            int sourceCount=0;
            for(String source:sources) { try { String body=download(source); if(body==null) continue; sourceCount++; parseLines(body,found); } catch(Exception ignored) {} }
            if(found.isEmpty()) { runOnUiThread(()->finishScan("دریافت ناموفق بود. اتصال اینترنت یا دسترسی به GitHub را بررسی کنید.")); return; }
            List<Node> all=new ArrayList<>(found.values()); if(all.size()>1200) all=all.subList(0,1200);
            final int total=all.size(), sourcesOk=sourceCount;
            runOnUiThread(()->{ status.setText("دریافت تمام شد؛ بررسی اولیه اتصال سرورها…"); counts.setText("منابع پاسخ‌گو: "+sourcesOk+" • کانفیگ یکتا: "+total); });
            List<Future<?>> jobs=new ArrayList<>();
            for(Node n:all) jobs.add(pool.submit(()->test(n)));
            for(Future<?> f:jobs) try { f.get(); } catch(Exception ignored) {}
            List<Node> result=new ArrayList<>(all); result.sort((a,b)->{ if(a.ms<0) return 1; if(b.ms<0) return -1; return Long.compare(a.ms,b.ms); });
            nodes.clear(); nodes.addAll(result);
            runOnUiThread(()->{ finishScan("آزمایش اولیه تمام شد. کانفیگ‌های سبز فقط از نظر دسترسی TCP بررسی شده‌اند."); render(); });
        }).start();
    }
    private String download(String urlText) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL(urlText).openConnection(); c.setConnectTimeout(9000); c.setReadTimeout(12000); c.setRequestProperty("User-Agent","V2RayFinder-Android/0.1"); try { if(c.getResponseCode()!=200) return null; InputStream in=c.getInputStream(); BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8)); StringBuilder s=new StringBuilder(); String line; int count=0; while((line=r.readLine())!=null && count++<100000) s.append(line).append('\n'); return s.toString(); } finally { c.disconnect(); } }
    private void parseLines(String body,Map<String,Node> out) { String trimmed=body.trim(); if(!trimmed.contains("://") && trimmed.length()>80) { try { String decoded=new String(Base64.getMimeDecoder().decode(trimmed),StandardCharsets.UTF_8); if(decoded.contains("://")) body=decoded; } catch(Exception ignored) {} }
        for(String line:body.split("\\r?\\n")) { String s=line.trim(); if(s.startsWith("vmess://")||s.startsWith("vless://")||s.startsWith("trojan://")||s.startsWith("ss://")||s.startsWith("socks://")) out.putIfAbsent(s,new Node(s)); }
    }
    private void test(Node n) { if(n.host==null||n.host.isEmpty()||n.port<1||n.port>65535) { n.result="قابل‌بررسی نیست"; return; } long start=System.currentTimeMillis(); try(Socket s=new Socket()) { s.connect(new InetSocketAddress(n.host,n.port),2500); n.ms=System.currentTimeMillis()-start; n.result="پورت در دسترس"; } catch(Exception e) { n.ms=-1; n.result="عدم دسترسی TCP"; } }
    private void finishScan(String message) { scanning=false; scanButton.setEnabled(true); status.setText(message); }
    private void render() { listBox.removeAllViews(); int alive=0; for(Node n:nodes) if(n.ms>=0) alive++; counts.setText("کل: "+nodes.size()+" • پورت قابل‌دسترسی: "+alive+" • ناموفق/نامشخص: "+(nodes.size()-alive));
        for(Node n:nodes) { LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setPadding(dp(12),dp(10),dp(12),dp(10)); item.setBackground(round(panel,13)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(7); listBox.addView(item,p);
            TextView name=new TextView(this); name.setText(n.proto+"  •  "+(n.host==null?"سرور نامشخص":n.host)+ (n.port>0?":"+n.port:"")); name.setTextColor(text); name.setTypeface(null,Typeface.BOLD); name.setTextSize(14); item.addView(name);
            TextView stat=new TextView(this); stat.setText(n.result+(n.ms>=0?"  |  "+n.ms+" ms":"")); stat.setTextColor(n.ms>=0?Color.rgb(92,220,155):muted); stat.setTextSize(12); stat.setPadding(0,dp(5),0,0); item.addView(stat);
            TextView copy=new TextView(this); copy.setText("برای کپی و انتقال به V2RayNG لمس کنید"); copy.setTextColor(accent); copy.setTextSize(12); copy.setPadding(0,dp(6),0,0); item.addView(copy); item.setOnClickListener(v->copyNode(n));
        }
    }
    private void copyNode(Node n) { ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("V2Ray config",n.uri)); Toast.makeText(this,"کانفیگ کپی شد؛ آن را در V2RayNG وارد کنید.",Toast.LENGTH_LONG).show(); }
    private void exportAll() { StringBuilder b=new StringBuilder(); synchronized(nodes) { for(Node n:nodes) if(n.ms>=0) b.append(n.uri).append('\n'); } if(b.length()==0) { Toast.makeText(this,"هنوز کانفیگ قابل‌دسترسی ندارید؛ ابتدا جستجو و تست کنید.",Toast.LENGTH_SHORT).show(); return; } Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_SUBJECT,"V2Ray configs"); i.putExtra(Intent.EXTRA_TEXT,b.toString()); startActivity(Intent.createChooser(i,"ارسال کانفیگ‌ها")); }
    @Override protected void onDestroy() { super.onDestroy(); pool.shutdownNow(); }
}
